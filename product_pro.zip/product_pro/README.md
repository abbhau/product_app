Project's Title : Product_App

How to Install and Run the Project:
1) create a virtual enviornment in your local repository and activate it 
    create : virtualenv venv
    activate : venv\scripts\activate

2) install all the deprndincies required to the project
    pip install -r requirements.txt

3) run the migrate command to create an sqlite database
    py manage.py migrate

4) change directory : cd product_pro

5) run the server by using command
   py manage.py runserver

    

  
